create
    definer = root@localhost procedure get_booked_seats_proc(IN p_trip_id int, IN p_departure_date date)
BEGIN
    SELECT seat_list
    FROM ticket
    WHERE trip_id = p_trip_id AND departure_date = p_departure_date;
END;

