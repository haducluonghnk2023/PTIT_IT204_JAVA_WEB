create
    definer = root@localhost procedure FindSeatsByBusId(IN BusId int)
BEGIN
    SELECT
        id,
        license_plate,
        bus_type,
        row_seat,
        col_seat,
        (row_seat * col_seat) AS total_seat,
        image
    FROM Bus
    WHERE id = BusId;
END;

