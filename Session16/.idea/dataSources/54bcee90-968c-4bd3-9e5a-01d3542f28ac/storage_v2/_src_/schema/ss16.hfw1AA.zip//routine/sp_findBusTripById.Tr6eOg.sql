create
    definer = root@localhost procedure sp_findBusTripById(IN p_id int)
BEGIN
    SELECT * FROM bustrip WHERE id = p_id;
END;

