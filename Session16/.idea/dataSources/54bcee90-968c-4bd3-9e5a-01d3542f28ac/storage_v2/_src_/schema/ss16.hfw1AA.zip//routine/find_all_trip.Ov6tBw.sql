create
    definer = root@localhost procedure find_all_trip()
begin
    select * from trip;
end;

