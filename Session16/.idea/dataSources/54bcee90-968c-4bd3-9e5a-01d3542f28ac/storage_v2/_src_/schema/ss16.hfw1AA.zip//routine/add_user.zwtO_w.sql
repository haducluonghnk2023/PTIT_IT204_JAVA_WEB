create
    definer = root@localhost procedure add_user(IN p_username varchar(50), IN p_password varchar(255),
                                                IN p_email varchar(100), IN p_role enum ('admin', 'user'),
                                                IN p_status enum ('active', 'inactive'))
begin
    insert into users (username, password, email, role, status)
    values (p_username, p_password, p_email, p_role, p_status);
end;

