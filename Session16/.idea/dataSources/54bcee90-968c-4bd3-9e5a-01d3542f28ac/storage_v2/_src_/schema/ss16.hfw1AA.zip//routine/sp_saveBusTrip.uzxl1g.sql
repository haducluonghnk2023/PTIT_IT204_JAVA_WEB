create
    definer = root@localhost procedure sp_saveBusTrip(IN p_departure_point varchar(100), IN p_destination varchar(100),
                                                      IN p_departure_time datetime, IN p_arrival_time datetime,
                                                      IN p_bus_id int, IN p_seats_available int,
                                                      IN p_image varchar(255))
BEGIN
    INSERT INTO bustrip (departure_point, destination, departure_time, arrival_time, bus_id, seats_available, image)
    VALUES (p_departure_point, p_destination, p_departure_time, p_arrival_time, p_bus_id, p_seats_available, p_image);
END;

