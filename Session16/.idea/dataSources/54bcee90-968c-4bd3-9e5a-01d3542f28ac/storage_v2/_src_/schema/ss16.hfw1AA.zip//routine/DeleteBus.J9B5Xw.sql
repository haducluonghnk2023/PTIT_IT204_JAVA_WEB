create
    definer = root@localhost procedure DeleteBus(IN p_id int)
BEGIN
    -- Xóa ghế trước vì có ràng buộc khóa ngoại
    DELETE FROM seat WHERE busId = p_id;

    -- Xóa xe
    DELETE FROM bus WHERE id = p_id;
END;

