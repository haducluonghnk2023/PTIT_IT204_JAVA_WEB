create
    definer = root@localhost procedure find_user_by_username(IN p_username varchar(50))
begin
    select * from users where username = p_username;
end;

