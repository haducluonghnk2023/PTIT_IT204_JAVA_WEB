create
    definer = root@localhost procedure FindAllBuses()
BEGIN
    SELECT * FROM bus;
END;

