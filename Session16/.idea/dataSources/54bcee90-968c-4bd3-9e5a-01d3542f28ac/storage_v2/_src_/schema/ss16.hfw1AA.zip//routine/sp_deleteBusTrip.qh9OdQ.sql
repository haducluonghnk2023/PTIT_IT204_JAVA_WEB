create
    definer = root@localhost procedure sp_deleteBusTrip(IN p_id int)
BEGIN
    DELETE FROM bustrip WHERE id = p_id;
END;

