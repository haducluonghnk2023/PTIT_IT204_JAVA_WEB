create
    definer = root@localhost procedure sp_updateBusTrip(IN p_id int, IN p_departure_point varchar(100),
                                                        IN p_destination varchar(100), IN p_departure_time datetime,
                                                        IN p_arrival_time datetime, IN p_bus_id int,
                                                        IN p_seats_available int, IN p_image varchar(255))
BEGIN
    UPDATE bustrip
    SET
        departure_point = p_departure_point,
        destination = p_destination,
        departure_time = p_departure_time,
        arrival_time = p_arrival_time,
        bus_id = p_bus_id,
        seats_available = p_seats_available,
        image = p_image
    WHERE id = p_id;
END;

