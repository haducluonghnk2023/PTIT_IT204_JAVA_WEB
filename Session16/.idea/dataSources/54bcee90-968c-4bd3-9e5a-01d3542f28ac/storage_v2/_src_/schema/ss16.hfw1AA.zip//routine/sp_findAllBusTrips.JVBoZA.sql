create
    definer = root@localhost procedure sp_findAllBusTrips()
BEGIN
    SELECT * FROM bustrip;
END;

