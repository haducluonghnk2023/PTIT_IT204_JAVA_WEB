create
    definer = root@localhost procedure search_trips(IN p_departure varchar(100), IN p_destination varchar(100),
                                                    IN p_offset int, IN p_limit int)
BEGIN
    SELECT * FROM trip
    WHERE departure LIKE CONCAT('%', p_departure, '%')
      AND destination LIKE CONCAT('%', p_destination, '%')
    ORDER BY departure_time ASC
    LIMIT p_offset, p_limit;
END;

