create
    definer = root@localhost procedure AddBus(IN p_licensePlate varchar(50), IN p_busType varchar(20),
                                              IN p_rowSeats int, IN p_columnSeats int, IN p_imageUrl varchar(255))
BEGIN
    INSERT INTO Bus (license_plate, bus_type, row_seat, col_seat, image)
    VALUES (p_licensePlate, p_busType, p_rowSeats, p_columnSeats, p_imageUrl);
END;

