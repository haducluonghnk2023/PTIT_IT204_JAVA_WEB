create
    definer = root@localhost procedure insert_ticket_proc(IN p_user_id int, IN p_trip_id int,
                                                          IN p_seat_list varchar(255), IN p_total_money decimal(10, 2),
                                                          IN p_departure_date date)
BEGIN
    -- Khai báo biến trước khi dùng
    DECLARE seat_count INT;

    -- Đếm số ghế đã đặt
    SET seat_count = LENGTH(p_seat_list) - LENGTH(REPLACE(p_seat_list, ',', '')) + 1;

    -- Thêm vé mới
    INSERT INTO ticket (user_id, trip_id, seat_list, total_money, departure_date)
    VALUES (p_user_id, p_trip_id, p_seat_list, p_total_money, p_departure_date);

    -- Trừ số ghế trống trong chuyến xe
    UPDATE bustrip
    SET seats_available = seats_available - seat_count
    WHERE id = p_trip_id;
END;

