create definer = root@localhost trigger after_delete_order
    after delete
    on orders
    for each row
begin 
	insert into deleted_orders(order_id,customer_name,product,order_date,delete_at) 
    values (old.order_id,old.customer_name,old.product,old.order_date,now());
end;

