create definer = root@localhost trigger after_insert_order
    after insert
    on orders
    for each row
begin
	if(new.quantity * new.price) > 5000 then
		insert into order_warnings (order_id,warning_message)
        values(new.order_id,'Total value exceeds limit');
	end if;
end;

