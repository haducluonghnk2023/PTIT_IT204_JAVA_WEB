create definer = root@localhost trigger after_update_price
    after update
    on orders
    for each row
begin
	if old.price <> new.price then
		INSERT INTO price_changes (change_id,product, old_price, new_price)
        VALUES (OLD.order_id,OLD.product, OLD.price, NEW.price);
	end if;
end;

