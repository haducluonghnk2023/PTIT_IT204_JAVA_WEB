create definer = root@localhost trigger after_delete_worker
    after delete
    on workers
    for each row
begin	
	update projects
    set total_salary = total_salary - old.salary
    where project_id = old.project_id;
end;

