create definer = root@localhost trigger before_insert_orders
    before insert
    on orders
    for each row
begin 
	if new.quantity is null or new.quantity < 1 then 
		set new.quantity = 1;
	end if;
    
	if new.order_date is null then
		set new.order_date = curdate();
    end if;
end;

