create definer = root@localhost view projectoverview as
select `p`.`project_id`        AS `project_id`,
       `p`.`name`              AS `project_name`,
       `p`.`budget`            AS `budget`,
       sum(`w`.`salary`)       AS `total_salary`,
       count(`w`.`project_id`) AS `worker_count`
from (`ss12`.`projects` `p` left join `ss12`.`workers` `w` on ((`p`.`project_id` = `w`.`project_id`)))
group by `p`.`project_id`, `p`.`name`, `p`.`budget`;

