create definer = root@localhost trigger after_update_total_salary
    after update
    on projects
    for each row
begin
    if new.total_salary > new.budget then
        if not exists (select 1 from budget_warnings where project_id = new.project_id) then
            insert into budget_warnings (project_id, warning_message)
            values (new.project_id, 'budget exceeded due to high salary');
        end if;
    else
        delete from budget_warnings where project_id = new.project_id;
    end if;
end;

