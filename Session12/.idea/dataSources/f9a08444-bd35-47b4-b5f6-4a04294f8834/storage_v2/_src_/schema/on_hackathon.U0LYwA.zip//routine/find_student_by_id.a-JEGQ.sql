create
    definer = root@localhost procedure find_student_by_id(IN student_id int)
BEGIN
    SELECT
        id,
        name,
        email,
        phone,
        sex,
        birthday,
        avatar,
        status
    FROM student
    WHERE id = student_id;
END;

