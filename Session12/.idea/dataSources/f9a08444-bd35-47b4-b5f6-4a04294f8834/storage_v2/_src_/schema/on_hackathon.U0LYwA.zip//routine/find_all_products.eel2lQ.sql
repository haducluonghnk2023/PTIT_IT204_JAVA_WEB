create
    definer = root@localhost procedure find_all_products()
BEGIN
    SELECT * FROM product;
END;

