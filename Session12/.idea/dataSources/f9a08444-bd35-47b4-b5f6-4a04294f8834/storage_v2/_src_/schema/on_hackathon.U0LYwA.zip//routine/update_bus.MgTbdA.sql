create
    definer = root@localhost procedure update_bus(IN p_id int, IN p_license_plate varchar(50),
                                                  IN p_bus_type enum ('NORMAL', 'VIP', 'LUXURY'), IN p_row_seat int,
                                                  IN p_col_seat int, IN p_image varchar(255))
BEGIN
    UPDATE bus
    SET license_plate = p_license_plate,
        bus_type = p_bus_type,
        row_seat = p_row_seat,
        col_seat = p_col_seat,
        image = p_image
    WHERE id = p_id;
END;

