create
    definer = root@localhost procedure get_all_buses()
BEGIN
    SELECT * FROM bus;
END;

