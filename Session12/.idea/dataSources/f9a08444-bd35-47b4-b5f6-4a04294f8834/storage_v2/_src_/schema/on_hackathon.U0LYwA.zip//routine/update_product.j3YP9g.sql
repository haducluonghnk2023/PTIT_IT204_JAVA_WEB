create
    definer = root@localhost procedure update_product(IN p_id int, IN p_name varchar(255), IN p_price decimal(10, 2),
                                                      IN p_quantity int, IN p_image varchar(255))
BEGIN
    UPDATE product
    SET name = p_name,
        price = p_price,
        quantity = p_quantity,
        image = p_image
    WHERE id = p_id;
END;

