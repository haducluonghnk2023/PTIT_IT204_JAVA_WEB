create
    definer = root@localhost procedure find_product_by_id(IN p_id int)
BEGIN
    SELECT * FROM product WHERE id = p_id;
END;

