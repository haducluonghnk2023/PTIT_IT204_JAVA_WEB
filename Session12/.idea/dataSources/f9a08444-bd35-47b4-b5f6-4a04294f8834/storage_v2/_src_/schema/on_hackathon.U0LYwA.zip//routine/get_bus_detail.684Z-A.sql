create
    definer = root@localhost procedure get_bus_detail(IN p_id int)
BEGIN
    -- Chi tiết xe
    SELECT * FROM bus WHERE id = p_id;

    -- Danh sách ghế của xe
    SELECT name_seat, price, status
    FROM seat
    WHERE bus_id = p_id
    ORDER BY name_seat;
END;

