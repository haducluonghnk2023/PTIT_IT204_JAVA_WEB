create
    definer = root@localhost procedure delete_product(IN p_id int)
BEGIN
    DELETE FROM product WHERE id = p_id;
END;

