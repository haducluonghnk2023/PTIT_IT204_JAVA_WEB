create
    definer = root@localhost procedure delete_bus(IN p_id int)
BEGIN
    DELETE FROM bus WHERE id = p_id;
    -- Ghế tự động xóa do ON DELETE CASCADE
END;

