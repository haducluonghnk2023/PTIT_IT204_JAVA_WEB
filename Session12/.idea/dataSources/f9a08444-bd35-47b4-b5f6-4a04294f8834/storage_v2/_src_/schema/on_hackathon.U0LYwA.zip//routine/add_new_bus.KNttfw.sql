create
    definer = root@localhost procedure add_new_bus(IN p_license_plate varchar(50),
                                                   IN p_bus_type enum ('NORMAL', 'VIP', 'LUXURY'), IN p_row_seat int,
                                                   IN p_col_seat int, IN p_image varchar(255))
BEGIN
    DECLARE v_bus_id INT;
    DECLARE r INT DEFAULT 1;
    DECLARE c INT;
    DECLARE seat_name VARCHAR(10);
    DECLARE price DECIMAL(10,2);

    -- Thêm xe
    INSERT INTO bus(license_plate, bus_type, row_seat, col_seat, image)
    VALUES (p_license_plate, p_bus_type, p_row_seat, p_col_seat, p_image);

    SET v_bus_id = LAST_INSERT_ID();

    -- Xác định giá ghế theo loại xe
    IF p_bus_type = 'NORMAL' THEN
        SET price = 100000;
    ELSEIF p_bus_type = 'VIP' THEN
        SET price = 150000;
    ELSE
        SET price = 200000;
    END IF;

    -- Tạo ghế theo hàng (r) và cột (c)
    WHILE r <= p_row_seat DO
            SET c = 1;
            WHILE c <= p_col_seat DO
                    SET seat_name = CONCAT(CHAR(64 + r), c); -- A1, A2,...
                    INSERT INTO seat(name_seat, price, bus_id)
                    VALUES (seat_name, price, v_bus_id);
                    SET c = c + 1;
                END WHILE;
            SET r = r + 1;
        END WHILE;
END;

