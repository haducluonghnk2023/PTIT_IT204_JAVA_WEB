create
    definer = root@localhost procedure delete_student(IN student_id int)
BEGIN
    DELETE FROM student WHERE id = student_id;
END;

