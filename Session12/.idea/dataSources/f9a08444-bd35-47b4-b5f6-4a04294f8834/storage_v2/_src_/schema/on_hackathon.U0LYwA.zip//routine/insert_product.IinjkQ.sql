create
    definer = root@localhost procedure insert_product(IN p_name varchar(255), IN p_price decimal(10, 2),
                                                      IN p_quantity int, IN p_image varchar(255))
BEGIN
    INSERT INTO product (name, price, quantity, image)
    VALUES (p_name, p_price, p_quantity, p_image);
END;

