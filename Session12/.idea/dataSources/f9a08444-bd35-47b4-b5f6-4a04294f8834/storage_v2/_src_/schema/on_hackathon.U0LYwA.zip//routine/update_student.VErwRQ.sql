create
    definer = root@localhost procedure update_student(IN p_id int, IN p_name varchar(100), IN p_email varchar(100),
                                                      IN p_phone varchar(20), IN p_sex tinyint(1), IN p_birthday date,
                                                      IN p_avatar varchar(255), IN p_status varchar(20))
BEGIN
    UPDATE student
    SET
        name = p_name,
        email = p_email,
        phone = p_phone,
        sex = p_sex,
        birthday = p_birthday,
        avatar = p_avatar,
        status = p_status
    WHERE id = p_id;
END;

