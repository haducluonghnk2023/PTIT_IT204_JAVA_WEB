create
    definer = root@localhost procedure insert_student(IN name_in varchar(50), IN email_in varchar(200),
                                                      IN phone_in varchar(15), IN sex_in bit, IN birthday_in datetime,
                                                      IN avatar_in text, IN status_in varchar(10))
BEGIN
    INSERT INTO student (name, email, phone, sex, birthday, avatar, status)
    VALUES (name_in, email_in, phone_in, sex_in, birthday_in, avatar_in, status_in);
END;

