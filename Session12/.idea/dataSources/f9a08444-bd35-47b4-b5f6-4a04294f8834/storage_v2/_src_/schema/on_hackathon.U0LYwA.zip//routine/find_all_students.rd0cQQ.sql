create
    definer = root@localhost procedure find_all_students()
begin
    select * from student order by name;
end;

