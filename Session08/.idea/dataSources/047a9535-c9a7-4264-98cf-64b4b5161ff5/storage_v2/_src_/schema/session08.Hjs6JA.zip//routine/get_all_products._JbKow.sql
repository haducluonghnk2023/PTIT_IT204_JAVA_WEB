create
    definer = root@localhost procedure get_all_products()
begin
            select * from products;
        end;

