create
    definer = root@localhost procedure get_all_customers()
begin
            select * from customer;
        end;

