create
    definer = root@localhost procedure insert_product(IN p_name varchar(50), IN p_price decimal(10, 2), IN p_quantity int)
begin
        insert into products (name, price, quantity) values (p_name, p_price, p_quantity);
    end;

