create
    definer = root@localhost procedure delete_category(IN p_category_id int)
begin
    -- neu trong danh muc co san pham thi khong xoa duoc
    declare v_count int;
    select count(*) into v_count from product where category_id = p_category_id;
    if v_count > 0 then
        signal sqlstate '45000' set message_text = 'Khong the xoa danh muc nay vi co san pham';
    else
        delete from category where category_id = p_category_id;
    end if;
end;

