create
    definer = root@localhost procedure find_all_category()
begin
    select * from category order by category_id desc ;
end;

