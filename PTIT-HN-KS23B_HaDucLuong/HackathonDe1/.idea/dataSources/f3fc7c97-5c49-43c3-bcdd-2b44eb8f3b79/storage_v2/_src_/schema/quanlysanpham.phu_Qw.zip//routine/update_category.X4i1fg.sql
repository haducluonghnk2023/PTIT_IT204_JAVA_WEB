create
    definer = root@localhost procedure update_category(IN p_category_id int, IN p_category_name varchar(100),
                                                       IN p_category_description text, IN p_status bit)
begin
    update category
    set category_name = p_category_name,
        category_description = p_category_description,
        status = p_status
    where category_id = p_category_id;
end;

