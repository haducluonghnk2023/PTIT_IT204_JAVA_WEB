create
    definer = root@localhost procedure update_product(IN p_product_id int, IN p_product_name varchar(100),
                                                      IN p_product_description text, IN p_price double,
                                                      IN p_image_url varchar(255), IN p_status bit,
                                                      IN p_created_at datetime, IN p_category_id int)
begin
    update product
    set product_name = p_product_name,
        product_description = p_product_description,
        price = p_price,
        image_url = p_image_url,
        status = p_status,
        created_at = p_created_at,
        category_id = p_category_id
    where product_id = p_product_id;
end;

