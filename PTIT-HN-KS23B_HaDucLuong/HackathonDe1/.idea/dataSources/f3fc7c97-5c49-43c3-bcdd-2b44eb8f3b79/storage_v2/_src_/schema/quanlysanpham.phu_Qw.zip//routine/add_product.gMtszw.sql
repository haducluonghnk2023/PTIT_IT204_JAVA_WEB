create
    definer = root@localhost procedure add_product(IN p_product_name varchar(100), IN p_product_description text,
                                                   IN p_price double, IN p_image_url varchar(255), IN p_status bit,
                                                   IN p_created_at datetime, IN p_category_id int)
begin
    insert into product(product_name, product_description, price, image_url, status,created_at, category_id)
    values (p_product_name, p_product_description, p_price, p_image_url, p_status,p_created_at, p_category_id);
end;

