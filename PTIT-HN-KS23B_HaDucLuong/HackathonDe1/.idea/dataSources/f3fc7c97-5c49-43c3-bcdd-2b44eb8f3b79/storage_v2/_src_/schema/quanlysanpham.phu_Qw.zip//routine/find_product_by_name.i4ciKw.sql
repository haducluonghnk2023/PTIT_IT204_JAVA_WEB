create
    definer = root@localhost procedure find_product_by_name(IN p_product_name varchar(100))
begin
    select * from product where product_name like concat('%', p_product_name, '%');
end;

