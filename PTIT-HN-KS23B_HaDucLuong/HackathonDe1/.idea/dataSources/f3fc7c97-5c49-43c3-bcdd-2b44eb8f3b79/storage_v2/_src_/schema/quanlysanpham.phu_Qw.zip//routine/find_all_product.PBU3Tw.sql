create
    definer = root@localhost procedure find_all_product()
begin
    select * from product order by created_at desc;
end;

