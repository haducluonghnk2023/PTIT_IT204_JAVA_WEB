create
    definer = root@localhost procedure find_category_by_id(IN p_category_id int)
begin
    select * from category where category_id = p_category_id;
end;

