create
    definer = root@localhost procedure find_category_by_name(IN p_category_name varchar(100))
begin
    select * from category where category_name like concat('%', p_category_name, '%');
end;

