create
    definer = root@localhost procedure add_category(IN p_category_name varchar(100), IN p_category_description text,
                                                    IN p_status bit)
begin
    insert into category(category_name, category_description,status) values (p_category_name, p_category_description,p_status);
end;

