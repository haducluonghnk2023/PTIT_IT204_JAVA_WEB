create
    definer = root@localhost procedure find_product_by_id(IN p_product_id int)
begin
    select * from product where product_id = p_product_id;
end;

