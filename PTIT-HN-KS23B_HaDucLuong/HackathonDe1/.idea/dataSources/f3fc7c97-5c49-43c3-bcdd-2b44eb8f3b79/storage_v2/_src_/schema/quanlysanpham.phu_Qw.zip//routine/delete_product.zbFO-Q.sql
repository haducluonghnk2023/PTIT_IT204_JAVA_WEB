create
    definer = root@localhost procedure delete_product(IN p_product_id int)
begin
    delete from product where product_id = p_product_id;
end;

