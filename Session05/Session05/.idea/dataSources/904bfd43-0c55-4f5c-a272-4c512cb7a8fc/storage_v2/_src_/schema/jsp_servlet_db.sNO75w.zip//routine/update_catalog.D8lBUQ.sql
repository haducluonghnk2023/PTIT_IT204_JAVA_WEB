create
    definer = root@localhost procedure update_catalog(IN id_in int, IN name_in varchar(200), IN des_in text, IN status_in bit)
begin
    update Categories
    set catalog_name = name_in,
        catalog_description = des_in,
        catalog_status = status_in
    where catalog_id = id_in;
end;

