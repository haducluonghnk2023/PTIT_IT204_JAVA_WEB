create
    definer = root@localhost procedure find_all_categories()
begin
    select * from Categories;
end;

