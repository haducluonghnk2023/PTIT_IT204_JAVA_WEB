create
    definer = root@localhost procedure find_by_id(IN id_in int)
begin
    select * from Categories where catalog_id = id_in;
end;

