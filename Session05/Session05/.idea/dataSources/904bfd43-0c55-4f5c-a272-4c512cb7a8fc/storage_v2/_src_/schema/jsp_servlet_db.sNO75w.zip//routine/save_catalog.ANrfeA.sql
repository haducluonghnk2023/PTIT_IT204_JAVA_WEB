create
    definer = root@localhost procedure save_catalog(IN name_in varchar(200), IN des_in text, IN status_in bit)
begin
    insert into Categories(catalog_name, catalog_description, catalog_status)
    values (name_in, des_in, status_in);
end;

