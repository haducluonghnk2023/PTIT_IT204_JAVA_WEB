create
    definer = root@localhost procedure delete_catalog(IN id_in int)
BEGIN
    DELETE FROM Categories WHERE catalog_id = id_in;
END;

