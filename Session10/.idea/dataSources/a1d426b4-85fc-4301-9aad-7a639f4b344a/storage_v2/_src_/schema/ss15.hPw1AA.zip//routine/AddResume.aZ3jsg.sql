create
    definer = root@localhost procedure AddResume(IN p_fullName varchar(255), IN p_email varchar(255),
                                                 IN p_phoneNumber varchar(50), IN p_education text,
                                                 IN p_experience text, IN p_skills text)
BEGIN
    INSERT INTO resume (
        full_name, email, phone_number, education, experience, skills
    )
    VALUES (
               p_fullName, p_email, p_phoneNumber, p_education, p_experience, p_skills
           );
END;

