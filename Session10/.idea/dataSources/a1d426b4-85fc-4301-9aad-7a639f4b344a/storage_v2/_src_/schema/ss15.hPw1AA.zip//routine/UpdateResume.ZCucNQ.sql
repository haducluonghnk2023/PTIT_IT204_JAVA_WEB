create
    definer = root@localhost procedure UpdateResume(IN p_id bigint, IN p_fullName varchar(255), IN p_email varchar(255),
                                                    IN p_phoneNumber varchar(50), IN p_education text,
                                                    IN p_experience text, IN p_skills text)
BEGIN
    UPDATE resume
    SET
        full_name = p_fullName,
        email = p_email,
        phone_number = p_phoneNumber,
        education = p_education,
        experience = p_experience,
        skills = p_skills
    WHERE id = p_id;
END;

