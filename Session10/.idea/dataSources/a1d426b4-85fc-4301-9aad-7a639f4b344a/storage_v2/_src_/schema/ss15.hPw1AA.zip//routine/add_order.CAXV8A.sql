create
    definer = root@localhost procedure add_order(IN p_user_id int, IN p_recipient_name varchar(100),
                                                 IN p_address varchar(255), IN p_phone_number varchar(20),
                                                 IN p_product_id int, IN p_quantity int,
                                                 IN p_current_price decimal(10, 2))
BEGIN
    DECLARE v_order_id INT;

    -- Insert đơn hàng
    INSERT INTO orders(user_id, recipient_name, address, phone_number)
    VALUES (p_user_id, p_recipient_name, p_address, p_phone_number);

    -- Lấy order_id vừa thêm
    SET v_order_id = LAST_INSERT_ID();

    -- Insert chi tiết đơn hàng
    INSERT INTO order_detail(order_id, product_id, quantity, current_price)
    VALUES (v_order_id, p_product_id, p_quantity, p_current_price);
END;

