create
    definer = root@localhost procedure select_customer(IN input_username varchar(50), IN input_password varchar(100))
BEGIN
    SELECT * FROM customer
    WHERE username = input_username AND password = input_password;
END;

