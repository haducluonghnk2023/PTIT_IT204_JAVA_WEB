create
    definer = root@localhost procedure find_all_movie()
BEGIN
    SELECT * FROM movies;
END;

