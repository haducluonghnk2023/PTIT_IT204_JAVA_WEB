create
    definer = root@localhost procedure findByScheduleId(IN p_schedule_id bigint)
BEGIN
    SELECT s.id, s.seatNumber, s.price, s.status
    FROM seats s
             INNER JOIN schedules sch ON s.screenRoomId = sch.screenRoomId
    WHERE sch.id = p_schedule_id;
END;

