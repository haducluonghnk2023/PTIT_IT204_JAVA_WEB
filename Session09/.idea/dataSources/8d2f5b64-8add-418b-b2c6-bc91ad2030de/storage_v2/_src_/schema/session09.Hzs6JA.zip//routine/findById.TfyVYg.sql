create
    definer = root@localhost procedure findById(IN p_id bigint)
BEGIN
    SELECT id, movieTitle, showTime, screenRoomId, availableSeats, format
    FROM schedules
    WHERE id = p_id;
END;

