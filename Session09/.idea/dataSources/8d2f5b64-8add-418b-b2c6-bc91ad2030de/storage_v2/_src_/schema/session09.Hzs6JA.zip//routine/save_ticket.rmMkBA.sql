create
    definer = root@localhost procedure save_ticket(IN p_customer_id bigint, IN p_schedule_id bigint,
                                                   IN p_total_money double, OUT p_ticket_id bigint)
BEGIN
    INSERT INTO tickets(customerId, scheduleId, totalMoney)
    VALUES (p_customer_id, p_schedule_id, p_total_money);

    SET p_ticket_id = LAST_INSERT_ID();
END;

