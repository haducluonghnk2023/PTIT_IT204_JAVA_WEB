create
    definer = root@localhost procedure find_schedule_by_movie(IN movie_name varchar(255))
BEGIN
    SELECT s.id, s.movieTitle, s.showTime, s.screenRoomId, sr.screenRoomName, s.availableSeats, s.format
    FROM schedules s
             JOIN screenRooms sr ON s.screenRoomId = sr.id
    WHERE s.movieTitle = movie_name;
END;

