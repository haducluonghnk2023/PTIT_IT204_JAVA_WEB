create
    definer = root@localhost procedure save_ticket_seat(IN p_ticket_id bigint, IN p_seat_id bigint)
BEGIN
    INSERT INTO ticket_seats(ticketId, seatId)
    VALUES (p_ticket_id, p_seat_id);

    UPDATE seats
    SET status = 'booked'
    WHERE id = p_seat_id;
END;

