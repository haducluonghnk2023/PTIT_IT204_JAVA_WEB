create
    definer = root@localhost procedure find_screen_room_by_id(IN p_id bigint)
BEGIN
    SELECT * FROM ScreenRooms WHERE id = p_id;
END;

