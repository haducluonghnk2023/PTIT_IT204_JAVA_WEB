create
    definer = root@localhost procedure find_movie_by_id(IN input_id bigint)
BEGIN
    SELECT * FROM movies WHERE id = input_id;
END;

