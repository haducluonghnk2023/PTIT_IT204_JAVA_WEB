create
    definer = root@localhost procedure find_all_screenrooms()
BEGIN
    SELECT * FROM screenRooms;
END;

